import 'package:flutter/material.dart';
import 'login_screen.dart';

class SignUpScreen extends StatelessWidget {
  final emailController = TextEditingController();
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFDFDFD),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: ListView(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Icon(Icons.arrow_back),
                  Text("Need some help?", style: TextStyle(color: Colors.grey)),
                ],
              ),
              SizedBox(height: 30),
              Text("Getting started", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              Text("Create account to continue!", style: TextStyle(color: Colors.grey)),
              SizedBox(height: 20),
              Row(
                children: [
                  Icon(Icons.mail_outline, color: Colors.grey),
                  SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: emailController,
                      decoration: InputDecoration(hintText: "Email"),
                    ),
                  )
                ],
              ),
              SizedBox(height: 10),
              TextField(
                controller: usernameController,
                decoration: InputDecoration(
                  hintText: "Username",
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: "Password",
                  prefixIcon: Icon(Icons.lock_outline),
                  suffixIcon: Icon(Icons.remove_red_eye_outlined),
                ),
              ),
              SizedBox(height: 10),
              SwitchListTile(
                value: true,
                onChanged: (_) {},
                title: Text("Reminder me next time"),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  padding: EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {},
                child: Text("SIGN UP", style: TextStyle(color: Colors.white)),
              ),
              SizedBox(height: 10),
              Center(
                child: GestureDetector(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LoginScreen())),
                  child: Text("Already have an account? Sign in", style: TextStyle(color: Colors.orange)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
