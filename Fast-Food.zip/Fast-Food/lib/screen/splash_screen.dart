import 'package:flutter/material.dart';
import 'signup_screen.dart';

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF86C33A),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.delivery_dining, size: 100, color: Colors.white),
            SizedBox(height: 20),
            Text('FOODCORT',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.white)),
            Text('FOOD DELIVER SERVICE',
                style: TextStyle(color: Colors.white70)),
            SizedBox(height: 50),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => SignUpScreen()));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                shape: CircleBorder(),
                padding: EdgeInsets.all(20),
              ),
              child: Icon(Icons.arrow_downward, color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
