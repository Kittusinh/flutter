import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFFDFDFD),
      appBar: AppBar(
        backgroundColor: Color(0xFFFDFDFD),
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text("Forgate your password?", style: TextStyle(color: Colors.grey)),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            Text("Let's get something", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            Text("Good to see you back.", style: TextStyle(color: Colors.grey)),
            SizedBox(height: 20),
            TextField(
              controller: usernameController,
              decoration: InputDecoration(
                hintText: "Username",
                prefixIcon: Icon(Icons.person_outline),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: "Password",
                prefixIcon: Icon(Icons.lock_outline),
                suffixIcon: Icon(Icons.remove_red_eye_outlined),
              ),
            ),
            SizedBox(height: 10),
            SwitchListTile(
              value: true,
              onChanged: (_) {},
              title: Text("Reminder me next time"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () {},
              child: Text("SIGN IN", style: TextStyle(color: Colors.white)),
            ),
            SizedBox(height: 10),
            Center(
              child: Text("Don’t have account? Sign in", style: TextStyle(color: Colors.orange)),
            ),
          ],
        ),
      ),
    );
  }
}
